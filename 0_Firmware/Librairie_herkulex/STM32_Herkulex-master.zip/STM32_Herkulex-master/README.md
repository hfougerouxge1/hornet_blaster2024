# Herkulex DRS-0101/0201 STM32F4xx library

This library was developed for use with an STM32F405 development board and Herkulex DRS-0101 Smart Servomotors. 

Originally ported from the Herkulex libraries developed by Alessandro Giacomel for Arduino.

Herkulex Manual: http://hovis.co.kr/guide/herkulex/drs-0101/%5BENG%5D%20Herkulex%20Manual_20140218.pdf